    @extends('template.default')
    @section('content')
    <section>
        <h1 class="titulo">Home </h1>
        <img src="{!! asset('img/fundo.jpg')!!}" class="image"/>
    </section>

    @endsection