    <?php $__env->startSection('content'); ?>
    <section>
        <h1 class="titulo">Cliente</h1>
        <div>
            <form>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Nome" name="txNome" value="Insira seu nome"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Data de nascimento - escreva em XXXX-XX-XX" name="txData" value="Insira sua data de nasc"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="EstadoCiv" name="txCiv" value="Insira seu Estado Civil"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="textarea" placeholder="Endereço" name="txEnd" value="Insira seu endereço"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="Número" name="txNum" value="Insira seu número"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Complemento" name="txCom" value="Insira seu complemento"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="CEP" name="txCEP" value="Insira seu CEP"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Cidade" name="txCid" value="Insira cidade"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Estado" name="txEst" value="Insira estado"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="RG" name="txRG" value="Insira seu RG"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="number" placeholder="CPF" name="txCPF" value="Insira seu CPF"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="email" placeholder="Email" name="txEmail" value="Insira seu email"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Telefone" name="txTel" value="Insira seu telefone"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Celular" name="txCel" value="Insira seu celular"/>
        </div>
        <div class="espaco">
            <input class="btn btn-danger" type="submit" value="Salvar"/>
        </div>

            </form>
        </div>
                <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="space">
                <h1> IdCliente: <?php echo e($pe->idCliente); ?> </h1>
                <p> Nome: <?php echo e($pe->nome); ?> </p>
                <p> Data de Nascimento: <?php echo e($pe->dataNasc); ?> </p>
                <p> Estado Civil: <?php echo e($pe->estadoCivil); ?> </p>
                <p> Endereço: <?php echo e($pe->endereco); ?> </p>
                <p> Número: <?php echo e($pe->numero); ?> </p>
                <p> Complemento: <?php echo e($pe->complemento); ?> </p>
                <p> CEP: <?php echo e($pe->cep); ?> </p>
                <p> Cidade: <?php echo e($pe->cidade); ?> </p>
                <p> Estado: <?php echo e($pe->estado); ?> </p>
                <p> RG: <?php echo e($pe->Rg); ?> </p>
                <p> CPF: <?php echo e($pe->cpf); ?> </p>
                <p> Email: <?php echo e($pe->email); ?> </p>
                <p> Telefone: <?php echo e($pe->fone); ?> </p>
                <p> Celular: <?php echo e($pe->celular); ?> </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>