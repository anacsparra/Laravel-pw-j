    <?php $__env->startSection('content'); ?>
    <section>
        <h1 class="titulo">Produto</h1>
        <div>
            <form action="<?php echo e(url('/produto/inserir')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="espaco">
            <input  class="form-control" type="text" name="txIdCategoria" placeholder="Insira o ID da categoria"/>
        </div>        
        <div class="espaco">
            <input  class="form-control" type="text" name="txProduto" placeholder="Insira um produto"/>
        </div>
        <div class="espaco">
            <input  class="form-control" type="text" name="txValor" placeholder="Insira o valor"/>
        </div>
        <div class="espaco-but">
            <input class="btn btn-danger" type="submit" placeholder="Salvar"/>
        </div>

            </form>
        </div>
        <div class="linha-space">
            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="space">
            <h1> IdProduto: <?php echo e($p->idProduto); ?> </h1>
            <p> IdCategoria: <?php echo e($p->idCategoria); ?> </p>
            <p> Produto: <?php echo e($p->produto); ?> </p>
            <p> Valor: <?php echo e($p->valor); ?> </p>
            <a href="/produto/<?php echo e($p->idProduto); ?>"> <img src="<?php echo asset('img/lixeira.png'); ?>" class="lixeira" /></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>