    <?php $__env->startSection('content'); ?>
    <section>
        <h1 class="titulo">Categoria</h1>
        <div>
            <form action="<?php echo e(url('/categoria/inserir')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="espaco">
            <input  class="form-control" type="text" placeholder="Categoria" name="txCategoria" value="Insira uma categoria"/>
        </div>

        <div class="espaco">
            <input class="btn btn-danger" type="submit" value="Salvar"/>
        </div>

            </form>
        </div>
            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="space">
            <h2 > Id Categoria: <?php echo e($cat->idCategoria); ?> </h2>
            <p> Categoria: <?php echo e($cat->categoria); ?> </p>
            <a href="/categoria/<?php echo e($cat->idCategoria); ?>"> <img src="<?php echo asset('img/lixeira.png'); ?>" class="lixeira" /> </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>