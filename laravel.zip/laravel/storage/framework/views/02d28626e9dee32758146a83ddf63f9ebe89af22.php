    
    <?php $__env->startSection('content'); ?>
    <section>
        <h1 class="titulo">Home </h1>
        <img src="<?php echo asset('img/fundo.jpg'); ?>" class="image"/>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>